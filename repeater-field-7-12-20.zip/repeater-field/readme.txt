=== Repeater Field ===

Plugin Name: Repeater Field
Tags: custom field, repeater field
Author URI: https://www.webuters.com/
Author: Webuters Teams
Requires at least: 5.4
Tested up to: 5.8.2
Stable tag: 1.0
Version: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Repeater Field can manage multiple fields including textbox, textarea, texteditor plus you can add more fields to wordpress posts and pages.
